"""Qt5/Qt6 ja QGIS 3/4 -yhteensopivuus."""
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QHeaderView, QTableWidget


def _enum(path, fallback_name):
    obj = Qt
    try:
        for part in path.split("."):
            obj = getattr(obj, part)
        return obj
    except AttributeError:
        return getattr(Qt, fallback_name)


AlignCenter = _enum("AlignmentFlag.AlignCenter", "AlignCenter")
StaysOnTop = _enum("WindowType.WindowStaysOnTopHint", "WindowStaysOnTopHint")
LeftButton = _enum("MouseButton.LeftButton", "LeftButton")
RightButton = _enum("MouseButton.RightButton", "RightButton")
Key_Escape = _enum("Key.Key_Escape", "Key_Escape")
Key_Backspace = _enum("Key.Key_Backspace", "Key_Backspace")
CrossCursor = _enum("CursorShape.CrossCursor", "CrossCursor")
PointingHandCursor = _enum("CursorShape.PointingHandCursor", "PointingHandCursor")


def polygon_geometry_type():
    try:
        from qgis.core import Qgis
        return Qgis.GeometryType.Polygon
    except AttributeError:
        from qgis.core import QgsWkbTypes
        return QgsWkbTypes.PolygonGeometry


def header_stretch(header):
    try:
        header.setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
    except AttributeError:
        header.setSectionResizeMode(QHeaderView.Stretch)


def no_edit_triggers(table):
    try:
        table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
    except AttributeError:
        table.setEditTriggers(QTableWidget.NoEditTriggers)
