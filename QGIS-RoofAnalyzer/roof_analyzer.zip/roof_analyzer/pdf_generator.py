"""PDF-raportti (reportlab)."""
import os
import datetime

from .analysis_engine import aspect_to_compass


def _f(x, d=1):
    return f"{x:.{d}f}".replace(".", ",")


def _register_fonts():
    """TrueType-fontti ääkkösille ja m²-merkille (perusfontista ² puuttuu)."""
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont
    windir = os.environ.get("WINDIR", r"C:\Windows")
    pairs = [
        (os.path.join(windir, "Fonts", "arial.ttf"), os.path.join(windir, "Fonts", "arialbd.ttf")),
        (os.path.join(windir, "Fonts", "segoeui.ttf"), os.path.join(windir, "Fonts", "segoeuib.ttf")),
        ("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
         "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"),
    ]
    for reg, bold in pairs:
        if os.path.exists(reg) and os.path.exists(bold):
            try:
                pdfmetrics.registerFont(TTFont("RA", reg))
                pdfmetrics.registerFont(TTFont("RA-Bold", bold))
                return "RA", "RA-Bold", "²"
            except Exception:
                pass
    return "Helvetica", "Helvetica-Bold", "2"


def generate_pdf(output_path, result, map_image_path=None, address=""):
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.units import cm
    from reportlab.lib.styles import ParagraphStyle
    from reportlab.lib.enums import TA_CENTER
    from reportlab.platypus import (SimpleDocTemplate, Table, TableStyle, Paragraph,
                                    Spacer, Image)

    FN, FB, SQ = _register_fonts()
    orange = colors.HexColor("#E65000")
    doc = SimpleDocTemplate(output_path, pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm,
                            topMargin=1.6 * cm, bottomMargin=1.6 * cm,
                            title="Kattopinta-ala-analyysi")
    h1 = ParagraphStyle("h1", fontName=FB, fontSize=18, leading=24, alignment=TA_CENTER, spaceAfter=6)
    sub = ParagraphStyle("sub", fontName=FN, fontSize=10, alignment=TA_CENTER,
                         textColor=colors.grey, spaceAfter=2)
    h2 = ParagraphStyle("h2", fontName=FB, fontSize=12, spaceBefore=8, spaceAfter=4)
    note = ParagraphStyle("note", fontName=FN, fontSize=8, textColor=colors.grey, leading=10)

    story = [Paragraph("Kattopinta-ala-analyysi", h1)]
    if address:
        story.append(Paragraph(address, sub))
    story.append(Paragraph(datetime.datetime.now().strftime("Laskettu %d.%m.%Y"), sub))
    story.append(Spacer(1, 0.3 * cm))

    if map_image_path and os.path.exists(map_image_path):
        story.append(Image(map_image_path, width=16 * cm, height=11 * cm))
        story.append(Spacer(1, 0.3 * cm))

    planes = result["planes"]
    d = result["diagnostics"]
    summary = [
        ["Katon todellinen pinta-ala", f"{_f(result['area_3d'])} m{SQ}"],
        ["Katon projektiopinta-ala (ylhäältä)", f"{_f(result['area_2d'])} m{SQ}"],
        ["Kattolappeita", str(len(planes))],
        ["Katon keskimääräinen kaltevuus", f"{_f(result.get('mean_slope_deg', 0))}°"],
    ]
    t = Table(summary, colWidths=[10 * cm, 6 * cm])
    t.setStyle(TableStyle([
        ("FONTNAME", (0, 0), (-1, -1), FN),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
        ("FONTNAME", (0, 0), (-1, 0), FB),
        ("FONTSIZE", (0, 0), (-1, 0), 13),
        ("TEXTCOLOR", (0, 0), (-1, 0), orange),
        ("LINEBELOW", (0, 0), (-1, 0), 1, orange),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story += [Paragraph("Yhteenveto", h2), t]

    rows = [["Lape", f"Projektio m{SQ}", f"Todellinen m{SQ}", "Kaltevuus", "Suunta"]]
    for p in planes:
        rows.append([str(p["id"]), _f(p["area_2d"]), _f(p["area_3d"]), f"{_f(p['slope_deg'])}°",
                     "tasainen" if p["flat"] else
                     f"{aspect_to_compass(p['aspect_deg'])} ({p['aspect_deg']:.0f}°)"])
    rows.append(["Yhteensä", _f(result["area_2d"]), _f(result["area_3d"]), "", ""])
    pt = Table(rows, colWidths=[2.2 * cm, 3.3 * cm, 3.5 * cm, 3 * cm, 4 * cm])
    pt.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#333333")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), FB),
        ("FONTNAME", (0, 1), (-1, -1), FN),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("ALIGN", (0, 0), (-1, -1), "CENTER"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -2), [colors.white, colors.HexColor("#F5F5F5")]),
        ("BACKGROUND", (0, -1), (-1, -1), colors.HexColor("#FFE0CC")),
        ("FONTNAME", (0, -1), (-1, -1), FB),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#CCCCCC")),
    ]))
    story += [Paragraph("Kattolappeet", h2), pt, Spacer(1, 0.5 * cm)]

    files = ", ".join(d.get("files", []))
    story.append(Paragraph(
        "Menetelmä: Maanmittauslaitoksen laserkeilausaineisto "
        f"({_f(d.get('density', 0))} pistettä/m{SQ} katolla{', ' + files if files else ''}). "
        "Kaltevuus lasketaan 0,5 m ruuduittain laserpisteisiin sovitetuista tasoista ja todellinen "
        "pinta-ala ruuduittain kaltevuus huomioiden. Lappeiden numerot vastaavat kartan numerointia. "
        "Tulokset ovat laskennallisia arvioita; tarkista mitat ennen materiaalitilausta.", note))
    doc.build(story)
