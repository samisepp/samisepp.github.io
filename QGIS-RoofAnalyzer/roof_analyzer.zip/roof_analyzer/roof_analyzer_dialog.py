import os
import csv
import datetime
import tempfile

from qgis.PyQt.QtCore import QThread, pyqtSignal, QSize
from qgis.PyQt.QtGui import QColor, QFont
from qgis.PyQt.QtWidgets import (
    QDialog, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, QFileDialog,
    QLineEdit, QTableWidget, QTableWidgetItem, QGroupBox, QProgressBar,
    QMessageBox, QDoubleSpinBox, QCheckBox)
from qgis.gui import QgsRubberBand
from qgis.core import (
    QgsProject, QgsGeometry, QgsCoordinateReferenceSystem, QgsCoordinateTransform,
    QgsVectorLayer, QgsFeature, QgsFillSymbol, QgsLineSymbol, QgsSingleSymbolRenderer,
    QgsCategorizedSymbolRenderer, QgsRendererCategory, QgsRectangle, QgsSettings,
    QgsMapRendererSequentialJob)

from . import compat
from .analysis_engine import DATA_EPSG, aspect_to_compass
from .map_tools import BuildingPickTool, PolygonDrawTool

SETTINGS = "roof_analyzer/"
PALETTE = [(230, 80, 0), (30, 120, 180), (40, 160, 40), (180, 30, 180),
           (200, 170, 0), (0, 170, 170), (140, 90, 40), (220, 60, 120)]


def fmt(x, d=1):
    return f"{x:.{d}f}".replace(".", ",")


class AnalysisWorker(QThread):
    done = pyqtSignal(object)
    failed = pyqtSignal(str)
    progress = pyqtSignal(int, str)

    def __init__(self, laz_index, wkt, buffer_m, manual):
        super().__init__()
        self.laz_index, self.wkt, self.buffer_m, self.manual = laz_index, wkt, buffer_m, manual

    def run(self):
        try:
            from .analysis_engine import analyze_building, AnalysisError
        except ImportError as e:
            self.failed.emit(f"Puuttuva kirjasto: {e}")
            return
        try:
            res = analyze_building(self.laz_index, self.wkt, self.buffer_m,
                                   progress=lambda p, m: self.progress.emit(p, m),
                                   manual=self.manual)
            self.done.emit(res)
        except AnalysisError as e:
            self.failed.emit(str(e))
        except ImportError as e:
            self.failed.emit(
                f"Puuttuva kirjasto: {e}\n\nAsenna OSGeo4W Shellissä:\n"
                "python -m pip install \"laspy[lazrs]\" scipy shapely reportlab")
        except Exception as e:
            import traceback
            self.failed.emit(f"Odottamaton virhe: {e}\n\n{traceback.format_exc()}")


class RoofAnalyzerDialog(QDialog):
    def __init__(self, iface, parent=None):
        super().__init__(parent)
        self.iface = iface
        self.canvas = iface.mapCanvas()
        self.data_crs = QgsCoordinateReferenceSystem(DATA_EPSG)
        self.laz_paths, self.laz_index = [], []
        self.building = None            # QgsGeometry EPSG:3067
        self.manual = False             # piirretty rajaus = ehdoton raja
        self.pick_buffer = 1.0
        self.result = None
        self.worker = None
        self.layer_ids = []
        self.pick_tool = BuildingPickTool(self.canvas, iface)
        self.pick_tool.picked.connect(self._building_picked)
        self.pick_tool.message.connect(lambda m: self._set_status(m, "#b00"))
        self.draw_tool = PolygonDrawTool(self.canvas)
        self.draw_tool.drawn.connect(self._building_drawn)
        self.sel_band = QgsRubberBand(self.canvas, compat.polygon_geometry_type())
        self.sel_band.setColor(QColor(255, 60, 0, 255))
        self.sel_band.setFillColor(QColor(255, 100, 0, 30))
        self.sel_band.setWidth(3)

        self.setWindowTitle("Roof Analyzer – kattopinta-ala")
        self.setMinimumWidth(560)
        self.setWindowFlags(self.windowFlags() | compat.StaysOnTop)
        self._build_ui()
        self._load_settings()

    # ------------------------------------------------------------------ UI --
    def _build_ui(self):
        lay = QVBoxLayout(self)

        g1 = QGroupBox("1. Laserkeilausaineisto (LAZ/LAS, ETRS-TM35FIN)")
        h = QHBoxLayout(g1)
        self.laz_edit = QLineEdit()
        self.laz_edit.setReadOnly(True)
        self.laz_edit.setPlaceholderText("Valitse tiedostot tai kansio...")
        b_files = QPushButton("Tiedostot...")
        b_files.clicked.connect(self._browse_files)
        b_dir = QPushButton("Kansio...")
        b_dir.clicked.connect(self._browse_dir)
        h.addWidget(self.laz_edit)
        h.addWidget(b_files)
        h.addWidget(b_dir)
        lay.addWidget(g1)

        g2 = QGroupBox("2. Rakennus")
        v = QVBoxLayout(g2)
        row = QHBoxLayout()
        self.btn_pick = QPushButton("👆  Valitse kartalta")
        self.btn_pick.setToolTip("Klikkaa rakennusta millä tahansa näkyvällä polygonitasolla,\n"
                                 "esim. Maastotietokannan rakennukset. Aktiivinen taso tarkistetaan ensin.")
        self.btn_pick.setStyleSheet("background:#E65000; color:white; font-weight:bold; padding:6px;")
        self.btn_pick.clicked.connect(lambda: self.canvas.setMapTool(self.pick_tool))
        self.btn_draw = QPushButton("✏️  Piirrä rajaus")
        self.btn_draw.setToolTip("Vasen klikkaus = piste, oikea tai kaksoisklikkaus = valmis,\n"
                                 "Backspace = poista piste, Esc = peru")
        self.btn_draw.clicked.connect(lambda: self.canvas.setMapTool(self.draw_tool))
        row.addWidget(self.btn_pick)
        row.addWidget(self.btn_draw)
        v.addLayout(row)
        self.status = QLabel("Valitse rakennus kartalta tai piirrä rajaus.")
        self.status.setWordWrap(True)
        self.status.setStyleSheet("color: grey;")
        v.addWidget(self.status)
        brow = QHBoxLayout()
        brow.addWidget(QLabel("Hakualueen puskuri:"))
        self.buffer_spin = QDoubleSpinBox()
        self.buffer_spin.setRange(0.0, 5.0)
        self.buffer_spin.setSingleStep(0.5)
        self.buffer_spin.setSuffix(" m")
        self.buffer_spin.setValue(1.0)
        self.buffer_spin.setToolTip(
            "Kuinka paljon rajauksen ulkopuolelta etsitään katon pisteitä.\n"
            "Räystäät ja rajauksen sijaintivirhe mahtuvat puskuriin; laserpisteet\n"
            "määräävät todellisen reunan. Piirretyllä rajauksella puskuri on oletuksena 0 m,\n"
            "jolloin piirretty viiva on ehdoton raja (esim. puiden rajaamiseksi pois).\n"
            "Kiinni olevissa rakennuksissa (rivitalot) käytä pientä arvoa.")
        brow.addWidget(self.buffer_spin)
        brow.addStretch()
        v.addLayout(brow)
        lay.addWidget(g2)

        arow = QHBoxLayout()
        arow.addWidget(QLabel("Kohteen osoite (PDF:ään):"))
        self.addr_edit = QLineEdit()
        arow.addWidget(self.addr_edit)
        lay.addLayout(arow)

        self.btn_run = QPushButton("🔍  Laske kattopinta-ala")
        self.btn_run.setStyleSheet("background:#2E7D32; color:white; font-weight:bold; "
                                   "font-size:13px; padding:8px;")
        self.btn_run.setEnabled(False)
        self.btn_run.clicked.connect(self._run)
        lay.addWidget(self.btn_run)
        self.progress = QProgressBar()
        self.progress.setVisible(False)
        self.progress_label = QLabel("")
        self.progress_label.setAlignment(compat.AlignCenter)
        lay.addWidget(self.progress)
        lay.addWidget(self.progress_label)

        g3 = QGroupBox("Tulokset")
        v3 = QVBoxLayout(g3)
        self.summary = QLabel("–")
        f = QFont()
        f.setPointSize(14)
        f.setBold(True)
        self.summary.setFont(f)
        self.summary.setStyleSheet("color:#E65000;")
        self.summary.setAlignment(compat.AlignCenter)
        v3.addWidget(self.summary)
        self.subsummary = QLabel("")
        self.subsummary.setAlignment(compat.AlignCenter)
        self.subsummary.setWordWrap(True)
        v3.addWidget(self.subsummary)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(
            ["Lape", "Projektio (m²)", "Todellinen (m²)", "Kaltevuus", "Suunta"])
        compat.header_stretch(self.table.horizontalHeader())
        compat.no_edit_triggers(self.table)
        self.table.setMaximumHeight(190)
        v3.addWidget(self.table)
        self.chk_debug = QCheckBox("Näytä diagnostiikka")
        v3.addWidget(self.chk_debug)
        self.debug = QLabel("–")
        self.debug.setWordWrap(True)
        self.debug.setStyleSheet("font-family:monospace; font-size:10px; background:#f5f5f5; padding:6px;")
        self.debug.setVisible(False)
        self.chk_debug.toggled.connect(self.debug.setVisible)
        v3.addWidget(self.debug)
        lay.addWidget(g3)

        brow2 = QHBoxLayout()
        self.btn_pdf = QPushButton("📄  PDF-raportti")
        self.btn_pdf.clicked.connect(self._export_pdf)
        self.btn_csv = QPushButton("📊  Lisää CSV-lokiin")
        self.btn_csv.setToolTip("Lisää tuloksen riviksi CSV-tiedostoon. Lokiin voi kirjata\n"
                                "vertailuarvot (esim. rakennuslupakuvista) validointia varten.")
        self.btn_csv.clicked.connect(self._append_csv)
        for b in (self.btn_pdf, self.btn_csv):
            b.setEnabled(False)
        b_clear = QPushButton("🗑  Tyhjennä")
        b_clear.clicked.connect(self._clear_all)
        brow2.addWidget(self.btn_pdf)
        brow2.addWidget(self.btn_csv)
        brow2.addWidget(b_clear)
        lay.addLayout(brow2)

    # ------------------------------------------------------------ asetukset --
    def _load_settings(self):
        s = QgsSettings()
        paths = [p for p in (s.value(SETTINGS + "laz_paths", "") or "").split("|") if p]
        if paths:
            self._set_laz(paths)
        try:
            self.pick_buffer = float(s.value(SETTINGS + "buffer", 1.0))
            self.buffer_spin.setValue(self.pick_buffer)
        except (TypeError, ValueError):
            pass

    def _save_settings(self):
        s = QgsSettings()
        s.setValue(SETTINGS + "laz_paths", "|".join(self.laz_paths))
        if not self.manual:
            self.pick_buffer = self.buffer_spin.value()
        s.setValue(SETTINGS + "buffer", self.pick_buffer)

    # ------------------------------------------------------------ LAZ --
    def _browse_files(self):
        paths, _ = QFileDialog.getOpenFileNames(self, "Valitse LAZ-tiedostot", "",
                                                "Laserkeilaus (*.laz *.las)")
        if paths:
            self._set_laz(paths)

    def _browse_dir(self):
        d = QFileDialog.getExistingDirectory(self, "Valitse kansio (myös alikansiot)")
        if not d:
            return
        paths = []
        for root, _, files in os.walk(d):
            paths += [os.path.join(root, f) for f in files if f.lower().endswith((".laz", ".las"))]
        if not paths:
            QMessageBox.warning(self, "Ei tiedostoja", "Kansiosta ei löytynyt LAZ/LAS-tiedostoja.")
            return
        self._set_laz(sorted(paths))

    def _set_laz(self, paths):
        from .analysis_engine import index_laz_files
        self.progress_label.setText("Luetaan tiedostojen otsakkeita...")
        self.repaint()
        try:
            idx = index_laz_files(paths)
        except ImportError as e:
            QMessageBox.critical(self, "Puuttuva kirjasto", f"{e}\n\nlaspy ei ole asennettuna.")
            return
        finally:
            self.progress_label.setText("")
        ok = [i for i in idx if i.get("bounds")]
        bad = [os.path.basename(i["path"]) for i in idx if not i.get("bounds")]
        self.laz_paths, self.laz_index = [i["path"] for i in ok], ok
        self.laz_edit.setText(f"{len(ok)} tiedostoa" if len(ok) != 1 else os.path.basename(ok[0]["path"]))
        self.laz_edit.setToolTip("\n".join(self.laz_paths[:40]) + ("\n..." if len(ok) > 40 else ""))
        if bad:
            QMessageBox.warning(self, "Osa tiedostoista ohitettiin",
                                "Näitä ei voitu lukea:\n" + "\n".join(bad[:20]))
        self._save_settings()
        self._check_ready()

    # ------------------------------------------------------------ rakennus --
    def _set_status(self, text, color="grey"):
        self.status.setText(text)
        self.status.setStyleSheet(f"color:{color};")

    def _set_building(self, geom, crs, source):
        g = QgsGeometry(geom)
        if crs != self.data_crs:
            g.transform(QgsCoordinateTransform(crs, self.data_crs, QgsProject.instance()))
        if g.isEmpty() or g.area() < 1.0:
            self._set_status("Rajaus on liian pieni.", "#b00")
            return
        self.building = g
        self.sel_band.setToGeometry(g, self.data_crs)
        self._set_status(f"✅ {source} – pohjapinta-ala {fmt(g.area())} m²", "green")
        self._check_ready()

    def _building_picked(self, geom, crs, layer_name):
        if self.manual:                          # palautetaan valinnan puskuri
            self.buffer_spin.setValue(self.pick_buffer)
        self.manual = False
        self._set_building(geom, crs, f"Valittu tasolta '{layer_name}' – puskuri "
                                      f"{fmt(self.buffer_spin.value())} m")

    def _building_drawn(self, geom, crs):
        if not self.manual:
            self.pick_buffer = self.buffer_spin.value()
        self.manual = True
        self.buffer_spin.setValue(0.0)           # piirretty raja käytetään sellaisenaan
        self._set_building(geom, crs, "Piirretty rajaus – käytetään sellaisenaan (puskuri 0 m)")

    def _check_ready(self):
        self.btn_run.setEnabled(bool(self.laz_index) and self.building is not None
                                and self.worker is None)

    # ------------------------------------------------------------ analyysi --
    def _run(self):
        self._save_settings()
        self.progress.setVisible(True)
        self.progress.setValue(0)
        self.btn_run.setEnabled(False)
        for b in (self.btn_pdf, self.btn_csv):
            b.setEnabled(False)
        self.summary.setText("Lasketaan...")
        self.subsummary.setText("")
        self.worker = AnalysisWorker(self.laz_index, self.building.asWkt(),
                                     self.buffer_spin.value(), self.manual)
        self.worker.progress.connect(lambda p, m: (self.progress.setValue(p),
                                                   self.progress_label.setText(m)))
        self.worker.done.connect(self._done)
        self.worker.failed.connect(self._failed)
        self.worker.start()

    def _finish_worker(self):
        self.progress.setVisible(False)
        self.progress_label.setText("")
        if self.worker:
            self.worker.wait()
        self.worker = None
        self._check_ready()

    def _failed(self, msg):
        self._finish_worker()
        self.summary.setText("Analyysi epäonnistui")
        QMessageBox.critical(self, "Virhe", msg)

    def _done(self, res):
        self._finish_worker()
        self.result = res
        self.summary.setText(f"Katon pinta-ala {fmt(res['area_3d'])} m²")
        warn = [v for k, v in res["diagnostics"].items() if k.startswith("warning")]
        sub = (f"Projektio {fmt(res['area_2d'])} m²  ·  keskikaltevuus {fmt(res['mean_slope_deg'])}°  ·  "
               f"{len(res['planes'])} lapetta")
        if warn:
            sub += "\n⚠ " + "\n⚠ ".join(warn)
        self.subsummary.setText(sub)
        self.subsummary.setStyleSheet("color:#b00;" if warn else "color:#333;")
        self._fill_table(res["planes"])
        self._fill_debug(res)
        self._show_layers(res)
        for b in (self.btn_pdf, self.btn_csv):
            b.setEnabled(True)

    def _fill_table(self, planes):
        self.table.setRowCount(len(planes))
        for r, p in enumerate(planes):
            vals = [f"Lape {p['id']}", fmt(p["area_2d"]), fmt(p["area_3d"]),
                    f"{fmt(p['slope_deg'])}°",
                    "tasainen" if p["flat"] else
                    f"{aspect_to_compass(p['aspect_deg'])} ({p['aspect_deg']:.0f}°)"]
            for c, val in enumerate(vals):
                it = QTableWidgetItem(val)
                it.setTextAlignment(compat.AlignCenter)
                self.table.setItem(r, c, it)

    def _fill_debug(self, res):
        d = res["diagnostics"]
        cls = "  ".join(f"lk{k}:{v}" for k, v in sorted(d.get("classes", {}).items()))
        self.debug.setText(
            f"Tiedostot: {', '.join(d.get('files', []))}\n"
            f"Pisteitä hakualueella+reunus: {d['points_total']}   luokat: {cls}\n"
            f"Yli 2 m maanpinnasta: {d['points_above_ground']}   tasomaisia: {d['points_planar']}\n"
            f"Pistetiheys katolla: {fmt(d['density'], 2)} p/m²   pisteväli {fmt(d['spacing'], 2)} m   "
            f"reunakorjaus {fmt(d['edge_offset'], 2)} m   katto hakualueen reunalla {d.get('clip_pct', 0)} %\n"
            f"Ruutuja: {d['cells']}   luotettavia: {d['cells_reliable_pct']} %   "
            f"pääsuunta {fmt(d['main_direction_deg'])}°   suoristetut harjat/taitteet {d.get('ridges_straightened', '-')}\n"
            f"Rakennuksen rajaus: {fmt(res['building_area'])} m²")

    # ------------------------------------------------------------ karttatasot --
    def _remove_layers(self):
        proj = QgsProject.instance()
        ids = [i for i in self.layer_ids if proj.mapLayer(i)]
        if ids:
            proj.removeMapLayers(ids)
        self.layer_ids = []

    def _show_layers(self, res):
        self._remove_layers()
        proj = QgsProject.instance()
        crs = DATA_EPSG

        outline = QgsVectorLayer(f"MultiPolygon?crs={crs}&field=todell_m2:double", "Katon reuna", "memory")
        f = QgsFeature(outline.fields())
        f.setGeometry(self._multi(res["outline"]))
        f.setAttributes([round(res["area_3d"], 1)])
        outline.dataProvider().addFeatures([f])
        outline.setRenderer(QgsSingleSymbolRenderer(QgsFillSymbol.createSimple(
            {"style": "no", "outline_color": "230,80,0,255", "outline_width": "0.8"})))

        planes = QgsVectorLayer(
            f"MultiPolygon?crs={crs}&field=lape:integer&field=proj_m2:double&field=todell_m2:double"
            f"&field=kaltevuus:double&field=suunta:string", "Kattolappeet", "memory")
        feats, cats = [], []
        for p in res["planes"]:
            f = QgsFeature(planes.fields())
            f.setGeometry(self._multi(p["geom"]))
            f.setAttributes([p["id"], round(p["area_2d"], 1), round(p["area_3d"], 1),
                             round(p["slope_deg"], 1),
                             "tasainen" if p["flat"] else aspect_to_compass(p["aspect_deg"])])
            feats.append(f)
            r, g, b = PALETTE[(p["id"] - 1) % len(PALETTE)]
            cats.append(QgsRendererCategory(p["id"], QgsFillSymbol.createSimple(
                {"color": f"{r},{g},{b},110", "outline_color": "40,40,40,160",
                 "outline_width": "0.2"}), f"Lape {p['id']}"))
        planes.dataProvider().addFeatures(feats)
        planes.setRenderer(QgsCategorizedSymbolRenderer("lape", cats))
        self._label_layer(planes)

        layers = [outline, planes]
        if res.get("ridges") is not None and not res["ridges"].is_empty:
            ridges = QgsVectorLayer(f"MultiLineString?crs={crs}", "Harjat ja taitteet", "memory")
            f = QgsFeature()
            f.setGeometry(self._multi(res["ridges"]))
            ridges.dataProvider().addFeatures([f])
            ridges.setRenderer(QgsSingleSymbolRenderer(QgsLineSymbol.createSimple(
                {"color": "20,20,20,230", "width": "0.5"})))
            layers.append(ridges)

        root = proj.layerTreeRoot()
        grp = root.findGroup("Roof Analyzer") or root.insertGroup(0, "Roof Analyzer")
        for lyr in layers:              # viimeinen päällimmäiseksi
            proj.addMapLayer(lyr, False)
            grp.insertLayer(0, lyr)
        self.layer_ids = [l.id() for l in layers]
        self.canvas.refresh()

    @staticmethod
    def _multi(shapely_geom):
        g = QgsGeometry.fromWkt(shapely_geom.wkt)
        g.convertToMultiType()
        return g

    @staticmethod
    def _label_layer(layer):
        try:
            from qgis.core import QgsPalLayerSettings, QgsTextFormat, QgsVectorLayerSimpleLabeling
            s = QgsPalLayerSettings()
            s.fieldName = "lape"
            s.enabled = True
            tf = QgsTextFormat()
            tf.setSize(11)
            tf.setColor(QColor(0, 0, 0))
            buf = tf.buffer()
            buf.setEnabled(True)
            buf.setSize(1.0)
            tf.setBuffer(buf)
            s.setFormat(tf)
            layer.setLabeling(QgsVectorLayerSimpleLabeling(s))
            layer.setLabelsEnabled(True)
        except Exception:
            pass

    # ------------------------------------------------------------ PDF & CSV --
    def _render_map(self, path):
        ms = self.canvas.mapSettings()
        x0, y0, x1, y1 = self.result["outline"].bounds
        pad = max(4.0, 0.25 * max(x1 - x0, y1 - y0))
        rect = QgsRectangle(x0 - pad, y0 - pad, x1 + pad, y1 + pad)
        tr = QgsCoordinateTransform(self.data_crs, ms.destinationCrs(), QgsProject.instance())
        ms.setExtent(tr.transformBoundingBox(rect))
        ms.setOutputSize(QSize(1600, 1100))
        ms.setBackgroundColor(QColor(255, 255, 255))
        proj = QgsProject.instance()
        ours = [proj.mapLayer(i) for i in reversed(self.layer_ids) if proj.mapLayer(i)]
        ms.setLayers(ours + [l for l in self.canvas.layers() if l.id() not in self.layer_ids])
        job = QgsMapRendererSequentialJob(ms)
        job.start()
        job.waitForFinished()
        job.renderedImage().save(path, "PNG")

    def _export_pdf(self):
        if not self.result:
            return
        name = (self.addr_edit.text().strip() or "katto").replace(" ", "_").replace(",", "")
        path, _ = QFileDialog.getSaveFileName(self, "Tallenna PDF", f"{name}.pdf", "PDF (*.pdf)")
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        img = os.path.join(tempfile.gettempdir(), "roof_analyzer_map.png")
        try:
            self._render_map(img)
        except Exception:
            img = None
        try:
            from .pdf_generator import generate_pdf
            generate_pdf(path, self.result, img, self.addr_edit.text().strip())
            QMessageBox.information(self, "PDF valmis", f"Tallennettu:\n{path}")
        except ImportError:
            QMessageBox.critical(self, "PDF-virhe", "reportlab puuttuu:\npython -m pip install reportlab")
        except Exception as e:
            QMessageBox.critical(self, "PDF-virhe", str(e))

    def _append_csv(self):
        if not self.result:
            return
        s = QgsSettings()
        path = s.value(SETTINGS + "csv_path", "")
        if not path:
            path, _ = QFileDialog.getSaveFileName(self, "Valitse CSV-loki", "katot_loki.csv", "CSV (*.csv)")
            if not path:
                return
            s.setValue(SETTINGS + "csv_path", path)
        r, d = self.result, self.result["diagnostics"]
        new = not os.path.exists(path)
        row = [datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), self.addr_edit.text().strip(),
               fmt(r["building_area"]), fmt(r["area_2d"]), fmt(r["area_3d"]), len(r["planes"]),
               " / ".join(f"{fmt(p['slope_deg'])}" for p in r["planes"]),
               fmt(d["density"], 2), ", ".join(d.get("files", [])),
               self.building.centroid().asWkt(1) if self.building else "", "", "", ""]
        try:
            with open(path, "a", newline="", encoding="utf-8-sig" if new else "utf-8") as fh:
                w = csv.writer(fh, delimiter=";")
                if new:
                    w.writerow(["aika", "osoite", "rajaus_m2", "projektio_m2", "todellinen_m2",
                                "lappeita", "kaltevuudet_deg", "pistetiheys", "tiedostot",
                                "sijainti_3067", "viite_todellinen_m2", "viite_kaltevuus_deg", "huomio"])
                w.writerow(row)
            self.progress_label.setText(f"Lisätty lokiin: {os.path.basename(path)}")
        except OSError as e:
            QMessageBox.critical(self, "CSV-virhe", f"{e}\n\nOnko tiedosto auki Excelissä?")

    # ------------------------------------------------------------ siivous --
    def _clear_all(self):
        self.building = None
        self.result = None
        self.sel_band.reset(compat.polygon_geometry_type())
        self.draw_tool.reset()
        self._remove_layers()
        self.table.setRowCount(0)
        self.summary.setText("–")
        self.subsummary.setText("")
        self.debug.setText("–")
        for b in (self.btn_pdf, self.btn_csv):
            b.setEnabled(False)
        self._set_status("Valitse rakennus kartalta tai piirrä rajaus.")
        self._check_ready()

    def cleanup(self):
        """Kutsutaan kun dialogi suljetaan tai plugin poistetaan."""
        for tool in (self.pick_tool, self.draw_tool):
            if self.canvas.mapTool() is tool:
                self.canvas.unsetMapTool(tool)
        self.draw_tool.reset()
        self.sel_band.reset(compat.polygon_geometry_type())

    def showEvent(self, event):
        if self.building is not None:
            self.sel_band.setToGeometry(self.building, self.data_crs)
        super().showEvent(event)

    def closeEvent(self, event):
        self.cleanup()
        super().closeEvent(event)
