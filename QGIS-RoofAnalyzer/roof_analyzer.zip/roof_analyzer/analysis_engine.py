"""
Roof Analyzer – analyysimoottori (ei QGIS-riippuvuuksia).

Menetelmä:
 1. Pisteet haetaan rakennuksen puskuroidulta hakualueelta (LAZ, EPSG:3067).
 2. Kattopisteet: luokat 1/5/6, vähintään 2 m maanpinnan (luokka 2) yläpuolella,
    ja paikallisesti tasomaiset (puiden latvukset ja savupiiput karsiutuvat).
 3. Katon reuna: alpha-shape kattopisteistä (vain ulkoreuna, ei reikiä),
    reunakorjaus puolen pistevälin verran, leikkaus hakualueeseen.
 4. 0,5 m ruudukko: jokaiselle ruudulle lasketaan kaltevuus ja ilmansuunta
    lähipisteisiin sovitetusta tasosta (pistenormaali).
 5. Lappeet: ruudut ryhmitellään ilmansuunnan mukaan rakennuksen pääsuuntiin
    (aspect-segmentointi); tasaiset ruudut omaksi luokakseen.
    Epäluotettavat ruudut (harjat, taitteet, portaat) liitetään lähimpään lappeeseen.
 6. Todellinen pinta-ala = Σ ruudun_ala_katon_sisällä / cos(ruudun_kaltevuus).
"""
import os
import sys
import math
import numpy as np

DATA_EPSG = "EPSG:3067"          # MML:n laserkeilausaineisto (ETRS-TM35FIN)
ROOF_CLASSES = (1, 5, 6)         # luokittelematon, korkea kasvillisuus, rakennus
GROUND_CLASS = 2
MIN_HEIGHT_ABOVE_GROUND = 2.0    # m
PLANARITY_MAX_RESID = 0.20       # m, pisteen lähiympäristön tasopoikkeama
CELL_RELIABLE_RESID = 0.08       # m, ruudun tasosovituksen luotettavuusraja
FLAT_SLOPE_DEG = 5.0             # tätä loivempi = tasakatto
TRANSITION_DEG = 8.0             # ero lappeen mediaanista -> siirtymäruutu
MIN_PLANE_AREA = 2.0             # m², pienemmät alueet liitetään naapuriin
MAX_SLOPE_DEG = 75.0


def _add_site_packages():
    """OSGeo4W:n käyttäjäkohtainen site-packages hakupolulle (laspy ym.)."""
    local = os.environ.get("LOCALAPPDATA", "")
    candidates = [
        os.path.join(local, "Programs", "OSGeo4W", "apps", "Python312", "Lib", "site-packages"),
        os.path.join(local, "Programs", "OSGeo4W", "apps", "Python311", "Lib", "site-packages"),
        r"C:\OSGeo4W\apps\Python312\Lib\site-packages",
        r"C:\OSGeo4W\apps\Python311\Lib\site-packages",
    ]
    for p in candidates:
        if p and os.path.isdir(p) and p not in sys.path:
            sys.path.append(p)


_add_site_packages()


class AnalysisError(Exception):
    """Käyttäjälle näytettävä virhe."""


# ---------------------------------------------------------------------------
# LAZ-tiedostot
# ---------------------------------------------------------------------------

def index_laz_files(paths):
    """Lukee tiedostojen otsakkeet (nopea) – palauttaa kattavuusalueet."""
    import laspy
    out = []
    for p in paths:
        try:
            with laspy.open(p) as f:
                h = f.header
                out.append({"path": p,
                            "bounds": (float(h.mins[0]), float(h.mins[1]),
                                       float(h.maxs[0]), float(h.maxs[1])),
                            "count": int(h.point_count)})
        except Exception as e:
            out.append({"path": p, "bounds": None, "error": str(e)})
    return out


def load_points(laz_index, bbox, progress=None):
    """Lukee vain bboxin sisällä olevat pisteet paloittain (ei koko tiedostoa muistiin)."""
    import laspy
    minx, miny, maxx, maxy = bbox
    files = [f for f in laz_index if f.get("bounds") and not (
        f["bounds"][2] < minx or f["bounds"][0] > maxx or
        f["bounds"][3] < miny or f["bounds"][1] > maxy)]
    if not files:
        raise AnalysisError(
            "Mikään valituista LAZ-tiedostoista ei kata rakennuksen aluetta.\n"
            "Tarkista että oikea karttalehti on valittu.")
    parts = []
    for i, f in enumerate(files):
        if progress:
            progress(15 + int(20 * i / len(files)),
                     f"Luetaan {os.path.basename(f['path'])}...")
        with laspy.open(f["path"]) as reader:
            for chunk in reader.chunk_iterator(2_000_000):
                x = np.asarray(chunk.x)
                y = np.asarray(chunk.y)
                m = (x >= minx) & (x <= maxx) & (y >= miny) & (y <= maxy)
                if m.any():
                    parts.append(np.column_stack([
                        x[m], y[m], np.asarray(chunk.z)[m],
                        np.asarray(chunk.classification)[m].astype(float)]))
    pts = np.vstack(parts) if parts else np.empty((0, 4))
    return pts, [f["path"] for f in files]


# ---------------------------------------------------------------------------
# Geometria-apurit
# ---------------------------------------------------------------------------

def _load_wkt_2d(wkt):
    from shapely import wkt as swkt
    from shapely.ops import transform
    g = swkt.loads(wkt)
    if g.has_z:
        g = transform(lambda x, y, z=None: (x, y), g)
    return g.buffer(0) if not g.is_valid else g


def _contains_xy(geom, x, y):
    try:
        import shapely
        return shapely.contains_xy(geom, x, y)
    except AttributeError:  # shapely < 2
        from shapely.prepared import prep
        from shapely.geometry import Point
        pg = prep(geom)
        return np.array([pg.contains(Point(a, b)) for a, b in zip(x, y)])


def _polygon_parts(g):
    if g.is_empty:
        return []
    return list(g.geoms) if g.geom_type in ("MultiPolygon", "GeometryCollection") else [g]


# ---------------------------------------------------------------------------
# Pistesuodatus
# ---------------------------------------------------------------------------

def _height_above_ground(xyz, ground):
    from scipy.spatial import cKDTree
    k = min(8, len(ground))
    _, idx = cKDTree(ground[:, :2]).query(xyz[:, :2], k=k)
    if k == 1:
        idx = idx[:, None]
    return xyz[:, 2] - np.median(ground[idx, 2], axis=1)


def _local_planes(query_xyz_or_xy, data_xyz, k=10, max_dist=np.inf, use_3d=True):
    """
    Sovittaa tason jokaisen kyselypisteen k lähimpään datapisteeseen.
    Palauttaa (normaalit N×3, jäännös-std N, naapurimäärä N).
    """
    from scipy.spatial import cKDTree
    k = min(k, len(data_xyz))
    tree = cKDTree(data_xyz if use_3d else data_xyz[:, :2])
    d, idx = tree.query(query_xyz_or_xy, k=k, distance_upper_bound=max_dist)
    if k == 1:
        d, idx = d[:, None], idx[:, None]
    valid = np.isfinite(d)
    idx = np.where(valid, idx, 0)
    w = valid.astype(float)[:, :, None]
    cnt = np.maximum(w.sum(axis=1), 1.0)                       # (n,1)
    nb = data_xyz[idx]                                         # (n,k,3)
    mean = (nb * w).sum(axis=1) / cnt
    c = (nb - mean[:, None, :]) * np.sqrt(w)
    cov = np.einsum("nki,nkj->nij", c, c) / cnt[:, :, None]
    evals, evecs = np.linalg.eigh(cov)
    normals = evecs[:, :, 0]
    normals[normals[:, 2] < 0] *= -1
    resid = np.sqrt(np.clip(evals[:, 0], 0, None))
    return normals, resid, valid.sum(axis=1)


# ---------------------------------------------------------------------------
# Katon reuna
# ---------------------------------------------------------------------------

def _alpha_parts(xy, radius):
    """Alpha-shape: säilytetään kolmiot joiden ympäripiirretyn ympyrän säde < radius.
    Palautetaan vain osien ULKOREUNAT (ei sisäreikiä)."""
    from scipy.spatial import Delaunay
    from shapely.geometry import Polygon
    from shapely.ops import unary_union
    tri = Delaunay(xy)
    s = tri.simplices
    a, b, c = xy[s[:, 0]], xy[s[:, 1]], xy[s[:, 2]]
    la = np.linalg.norm(b - c, axis=1)
    lb = np.linalg.norm(a - c, axis=1)
    lc = np.linalg.norm(a - b, axis=1)
    area = 0.5 * np.abs((b[:, 0] - a[:, 0]) * (c[:, 1] - a[:, 1]) -
                        (c[:, 0] - a[:, 0]) * (b[:, 1] - a[:, 1]))
    R = la * lb * lc / (4.0 * np.maximum(area, 1e-12))
    keep = np.nonzero((R < radius) & (area > 1e-9))[0]
    if len(keep) == 0:
        return []
    try:
        import shapely
        tris = shapely.polygons(np.stack([a[keep], b[keep], c[keep]], axis=1))
        merged = shapely.union_all(tris)
    except AttributeError:
        merged = unary_union([Polygon([a[i], b[i], c[i]]) for i in keep])
    return [Polygon(p.exterior) for p in _polygon_parts(merged) if p.area > 0]


def _clean(g):
    """Vain polygoniosat, korjattuna."""
    from shapely.ops import unary_union
    parts = [p for p in _polygon_parts(g) if p.geom_type == "Polygon" and p.area > 1e-4]
    if not parts:
        from shapely.geometry import Polygon
        return Polygon()
    u = unary_union(parts)
    return u if u.is_valid else u.buffer(0)


def _fit_plane(xyz):
    """Robusti taso z = a*x + b*y + c (paikalliset koordinaatit). None jos ei onnistu."""
    if len(xyz) < 12:
        return None
    A = np.column_stack([xyz[:, 0], xyz[:, 1], np.ones(len(xyz))])
    keep = np.ones(len(xyz), bool)
    for _ in range(3):
        coef, *_ = np.linalg.lstsq(A[keep], xyz[keep, 2], rcond=None)
        res = np.abs(A @ coef - xyz[:, 2])
        new_keep = res <= max(0.12, 2.5 * np.median(res[keep]))
        if new_keep.sum() < 12 or (new_keep == keep).all():
            break
        keep = new_keep
    rms = float(np.sqrt(np.mean((A[keep] @ coef - xyz[keep, 2]) ** 2)))
    return {"coef": coef, "rms": rms, "n": int(keep.sum())}


def _fit_label_planes(roof, labels, lids, origin, cell, nx, ny, structure):
    """Sovittaa tason jokaisen lappeen sisäosan pisteisiin (reunat pois, jotta
    harjan pisteet eivät vääristä tasoa)."""
    from scipy import ndimage
    col = np.floor((roof[:, 0] - origin[0]) / cell).astype(int)
    row = np.floor((origin[1] - roof[:, 1]) / cell).astype(int)
    ok = (col >= 0) & (col < nx) & (row >= 0) & (row < ny)
    local = np.column_stack([roof[:, 0] - origin[0], roof[:, 1] - origin[1], roof[:, 2]])
    fits = {}
    for lid in lids:
        m = labels == lid
        for it in (2, 1, 0):
            core = ndimage.binary_erosion(m, structure=structure, iterations=it) if it else m
            sel = np.zeros(len(roof), bool)
            sel[ok] = core[row[ok], col[ok]]
            if sel.sum() >= 15:
                break
        f = _fit_plane(local[sel])
        if f is not None and f["rms"] <= 0.15:
            fits[lid] = f
    return fits


def _straighten_pair(geoms, la, lb, fits, raster_line, segs, origin):
    """
    Korvaa kahden lappeen välisen porrasmaisen rajan lappeiden tasojen
    leikkaussuoralla. Palauttaa suoran janan (shapely) tai None jos ehdot
    eivät täyty (esim. porras kahden tasakaton välillä).
    """
    from shapely.geometry import LineString, Polygon
    from shapely.ops import unary_union
    if la not in fits or lb not in fits:
        return None
    ca, cb = fits[la]["coef"], fits[lb]["coef"]
    na = np.array([-ca[0], -ca[1], 1.0]); na /= np.linalg.norm(na)
    nb = np.array([-cb[0], -cb[1], 1.0]); nb /= np.linalg.norm(nb)
    if math.degrees(math.acos(min(1.0, abs(float(na @ nb))))) < 8.0:
        return None                                    # lähes yhdensuuntaiset tasot
    g = np.array([ca[0] - cb[0], ca[1] - cb[1]])
    dc = ca[2] - cb[2]
    gn2 = float(g @ g)
    if gn2 < 1e-9:
        return None
    gl = math.sqrt(gn2)
    # porrasrajan pitää kulkea leikkaussuoran lähellä
    mids = np.array([[(a[0] + b[0]) / 2 - origin[0], (a[1] + b[1]) / 2 - origin[1]] for a, b in segs])
    dist = np.abs(mids @ g + dc) / gl
    if dist.mean() > 0.6 or np.percentile(dist, 90) > 1.2:
        return None
    A, B = geoms[la], geoms[lb]
    zone = raster_line.buffer(1.2, cap_style=2).intersection(unary_union([A, B]))
    zone = _clean(zone)
    if zone.is_empty:
        return None
    za, zb = A.intersection(zone), B.intersection(zone)
    if za.area < 0.05 or zb.area < 0.05:
        return None
    side = lambda geom: float(np.array([geom.centroid.x - origin[0],
                                        geom.centroid.y - origin[1]]) @ g + dc)
    sa, sb = side(za), side(zb)
    if sa * sb >= 0:
        return None                                    # tasojen järjestys ei täsmää
    c = np.array([zone.centroid.x - origin[0], zone.centroid.y - origin[1]])
    pc = c - (float(c @ g) + dc) / gn2 * g
    d = np.array([-g[1], g[0]]) / gl
    gh = g / gl
    Lm = 500.0
    o = origin
    hp = Polygon([tuple(pc - Lm * d + o), tuple(pc + Lm * d + o),
                  tuple(pc + Lm * d + Lm * gh + o), tuple(pc - Lm * d + Lm * gh + o)])
    pos, neg = _clean(zone.intersection(hp)), _clean(zone.difference(hp))
    part_a, part_b = (pos, neg) if sa > 0 else (neg, pos)
    geoms[la] = _clean(unary_union([A.difference(zone), part_a]))
    geoms[lb] = _clean(unary_union([B.difference(zone), part_b]))
    line = LineString([tuple(pc - Lm * d + o), tuple(pc + Lm * d + o)]).intersection(zone)
    pieces = [p for p in (line.geoms if hasattr(line, "geoms") else [line])
              if p.geom_type == "LineString" and p.length > 0.3]
    if not pieces:
        return None
    return unary_union(pieces)


# ---------------------------------------------------------------------------
# Pääfunktio
# ---------------------------------------------------------------------------

def analyze_building(laz_index, building_wkt, buffer_m=1.0, cell=0.5, progress=None,
                     manual=False):
    """Lukee pisteet ja analysoi rakennuksen katon. Palauttaa tulossanakirjan."""
    building = _load_wkt_2d(building_wkt)
    if building.is_empty or building.area < 1.0:
        raise AnalysisError("Rakennuksen rajaus on tyhjä tai liian pieni.")
    search = building.buffer(buffer_m, join_style=2)
    margin = 6.0  # maanpintapisteitä varten rakennuksen ympäriltä
    minx, miny, maxx, maxy = search.bounds
    if progress:
        progress(10, "Etsitään pisteitä...")
    pts, used_files = load_points(laz_index, (minx - margin, miny - margin,
                                              maxx + margin, maxy + margin), progress)
    result = analyze_points(pts, building, search, cell=cell, progress=progress, manual=manual)
    result["diagnostics"]["files"] = [os.path.basename(p) for p in used_files]
    return result


def analyze_points(pts, building, search, cell=0.5, progress=None, manual=False):
    """manual=True: käyttäjän piirtämä rajaus on ehdoton raja (ei leikkausvaroitusta)."""
    """Analyysi valmiiksi luetuille pisteille (N×4: x, y, z, luokka)."""
    from scipy import ndimage
    from shapely.geometry import box
    from shapely.ops import unary_union, linemerge
    from shapely.geometry import MultiLineString

    diag = {"points_total": int(len(pts))}
    if len(pts) == 0:
        raise AnalysisError("Alueelta ei löytynyt yhtään laserpistettä.\n"
                            "Tarkista LAZ-tiedosto ja rakennuksen sijainti.")

    cls = pts[:, 3].astype(int)
    u, c = np.unique(cls, return_counts=True)
    diag["classes"] = {int(a): int(b) for a, b in zip(u, c)}

    # --- 1. Kattopisteet ----------------------------------------------------
    if progress:
        progress(40, "Suodatetaan kattopisteet...")
    in_search = _contains_xy(search, pts[:, 0], pts[:, 1])
    cand = pts[in_search & np.isin(cls, ROOF_CLASSES)]
    ground = pts[cls == GROUND_CLASS]
    if len(cand) < 20:
        raise AnalysisError(f"Hakualueelta löytyi vain {len(cand)} mahdollista kattopistettä.")
    if len(ground) >= 3:
        hag = _height_above_ground(cand[:, :3], ground)
        cand = cand[hag >= MIN_HEIGHT_ABOVE_GROUND]
    else:
        diag["warning_ground"] = "Maanpintapisteitä ei löytynyt – korkeusraja arvioitu."
        cand = cand[cand[:, 2] >= np.percentile(cand[:, 2], 20)]
    diag["points_above_ground"] = int(len(cand))
    if len(cand) < 20:
        raise AnalysisError("Maanpinnan yläpuolelta löytyi liian vähän pisteitä.")

    _, resid, _ = _local_planes(cand[:, :3], cand[:, :3], k=10)
    roof = cand[resid <= PLANARITY_MAX_RESID]
    diag["points_planar"] = int(len(roof))
    if len(roof) < 20:
        raise AnalysisError("Tasomaisia kattopisteitä löytyi liian vähän.")

    # --- 2. Katon reuna -----------------------------------------------------
    if progress:
        progress(55, "Muodostetaan katon reuna...")
    from scipy.spatial import cKDTree
    nn = cKDTree(roof[:, :2]).query(roof[:, :2], k=2)[0][:, 1]
    nn_med = float(np.median(nn))
    parts = _alpha_parts(roof[:, :2], radius=max(1.5, 4.0 * nn_med))
    sel = [p for p in parts if p.area >= 1.0 and
           p.intersection(building).area >= 0.3 * p.area]
    if not sel and parts:
        sel = [max(parts, key=lambda p: p.intersection(building).area)]
    if not sel:
        raise AnalysisError("Katon reunaa ei voitu muodostaa.")
    core = unary_union(sel)
    # Leikkaako hakualueen reuna kattoa? Jos kattopisteitä on aivan hakualueen
    # reunalla pitkällä matkalla, katto todennäköisesti jatkuu rajauksen yli.
    touch = core.boundary.intersection(search.boundary.buffer(0.15)).length
    clip_frac = touch / core.length if core.length > 0 else 0.0
    diag["clip_pct"] = int(round(100 * clip_frac))
    if clip_frac > 0.10 and not manual:
        diag["warning_clip"] = (
            f"Kattopisteitä on hakualueen reunalla {100 * clip_frac:.0f} % kehästä – katto "
            "jatkuu todennäköisesti rajauksen yli. Kasvata puskuria tai tarkista rajaus "
            "(kiinni olevassa rakennuksessa tämä on odotettavaa).")
    n_core = int(_contains_xy(core, roof[:, 0], roof[:, 1]).sum())
    density = n_core / core.area
    spacing = 1.0 / math.sqrt(density)
    edge_offset = min(0.45 * spacing, 0.4)
    outline = core.buffer(edge_offset, join_style=2, mitre_limit=2.0).intersection(search)
    outline = outline.simplify(0.1, preserve_topology=True)
    outline = unary_union([p for p in _polygon_parts(outline) if p.area >= 1.0])
    diag.update(density=round(density, 2), spacing=round(spacing, 2),
                edge_offset=round(edge_offset, 2))
    if density < 3.0:
        diag["warning_density"] = (f"Pistetiheys vain {density:.1f} p/m² – "
                                   "tulos epäluotettava (onko aineisto 0,5p?).")

    # käytetään normaalien laskennassa vain katon pisteitä (+1 m reunavara)
    near = _contains_xy(outline.buffer(1.0), roof[:, 0], roof[:, 1])
    roof = roof[near]

    # --- 3. Ruudukko ja ruutukohtaiset tasot --------------------------------
    if progress:
        progress(65, "Lasketaan kaltevuudet ruuduittain...")
    bx0, by0, bx1, by1 = outline.bounds
    nx = int(math.ceil((bx1 - bx0) / cell)) + 1
    ny = int(math.ceil((by1 - by0) / cell)) + 1
    xs = bx0 + (np.arange(nx) + 0.5) * cell
    ys = by1 - (np.arange(ny) + 0.5) * cell          # rivi 0 = pohjoinen
    X, Y = np.meshgrid(xs, ys)

    try:
        import shapely
        boxes = shapely.box(X - cell / 2, Y - cell / 2, X + cell / 2, Y + cell / 2)
        weight = shapely.area(shapely.intersection(boxes, outline))
    except AttributeError:
        inside = _contains_xy(outline, X.ravel(), Y.ravel()).reshape(X.shape)
        weight = inside * cell * cell
    roofmask = weight > 1e-6

    q = np.column_stack([X[roofmask], Y[roofmask]])
    normals, cres, ncount = _local_planes(q, roof[:, :3], k=10, max_dist=1.0, use_3d=False)
    slope_c = np.degrees(np.arccos(np.clip(normals[:, 2], -1, 1)))
    aspect_c = (np.degrees(np.arctan2(normals[:, 0], normals[:, 1])) + 360) % 360
    reliable_c = (ncount >= 6) & (cres <= CELL_RELIABLE_RESID) & (slope_c <= MAX_SLOPE_DEG)

    slope = np.full(X.shape, np.nan)
    aspect = np.full(X.shape, np.nan)
    reliable = np.zeros(X.shape, bool)
    slope[roofmask], aspect[roofmask], reliable[roofmask] = slope_c, aspect_c, reliable_c
    diag["cells"] = int(roofmask.sum())
    diag["cells_reliable_pct"] = int(100 * reliable_c.mean()) if len(reliable_c) else 0

    # --- 4. Aspect-segmentointi ---------------------------------------------
    if progress:
        progress(80, "Tunnistetaan lappeet...")
    sloped = reliable & (slope >= FLAT_SLOPE_DEG)
    flat = reliable & (slope < FLAT_SLOPE_DEG)
    # rakennuksen pääsuunta: ilmansuunnat "taitetaan" 90° jaksoon (4θ)
    if sloped.any():
        a = np.radians(aspect[sloped])
        theta0 = math.degrees(math.atan2(np.sin(4 * a).sum(), np.cos(4 * a).sum())) / 4.0
    else:
        theta0 = 0.0
    sector = np.full(X.shape, -1)
    sector[sloped] = np.round(((aspect[sloped] - theta0) % 360) / 90.0).astype(int) % 4
    sector[flat] = 4

    labels = np.zeros(X.shape, int)
    next_id = 1
    four = ndimage.generate_binary_structure(2, 1)
    min_cells = max(1, int(round(MIN_PLANE_AREA / (cell * cell))))
    for s in range(5):
        lab, n = ndimage.label(sector == s, structure=four)
        for k in range(1, n + 1):
            m = lab == k
            if m.sum() >= min_cells:
                labels[m] = next_id
                next_id += 1
    if next_id == 1:  # ei yhtään luotettavaa aluetta -> koko katto yhtenä
        labels[roofmask] = 1
        next_id = 2
    # epäluotettavat ja liian pienet ruudut -> lähin lape
    need = roofmask & (labels == 0)
    if need.any():
        _, (iy, ix) = ndimage.distance_transform_edt(labels == 0, return_indices=True)
        labels[need] = labels[iy[need], ix[need]]
    labels[~roofmask] = 0

    # --- 5. Lappeiden tilastot ja raakageometriat ----------------------------
    if progress:
        progress(88, "Lasketaan pinta-alat...")
    slope_eff = np.where(np.isnan(slope), 0.0, slope)
    lids = [int(v) for v in np.unique(labels[labels > 0])]
    stats, geoms = {}, {}
    for lid in lids:
        m = labels == lid
        good = m & reliable
        med = float(np.median(slope[good])) if good.any() else float(np.nanmedian(slope[m]))
        # siirtymäruudut (harjat, taitteet, portaat) saavat lappeen mediaanikaltevuuden
        repl = m & (~reliable | (np.abs(slope - med) > TRANSITION_DEG))
        slope_eff[repl] = med
        s_eff = np.clip(slope_eff[m], 0, MAX_SLOPE_DEG)
        a2 = float(weight[m].sum())
        a3 = float((weight[m] / np.cos(np.radians(s_eff))).sum())
        is_flat = med < FLAT_SLOPE_DEG
        if is_flat or not good.any():
            asp = None
        else:
            ar = np.radians(aspect[good])
            asp = (math.degrees(math.atan2(np.sin(ar).mean(), np.cos(ar).mean())) + 360) % 360
        stats[lid] = {"slope_deg": med, "aspect_deg": asp, "flat": is_flat,
                      "factor": a3 / a2 if a2 > 0 else 1.0}
        geoms[lid] = _clean(unary_union([box(X[i, j] - cell / 2, Y[i, j] - cell / 2,
                                             X[i, j] + cell / 2, Y[i, j] + cell / 2)
                                         for i, j in zip(*np.nonzero(m))]).intersection(outline))

    # --- 6. Suorat harjat ja taitteet lappeiden tasojen leikkauksena ----------
    if progress:
        progress(93, "Suoristetaan harjat ja taitteet...")
    origin = np.array([bx0, by1])
    fits = _fit_label_planes(roof, labels, lids, origin, cell, nx, ny, four)
    pair_segs = {}
    L = labels
    for i, j in zip(*np.nonzero((L[:, :-1] > 0) & (L[:, 1:] > 0) & (L[:, :-1] != L[:, 1:]))):
        xe = X[i, j] + cell / 2
        key = tuple(sorted((int(L[i, j]), int(L[i, j + 1]))))
        pair_segs.setdefault(key, []).append(((xe, Y[i, j] - cell / 2), (xe, Y[i, j] + cell / 2)))
    for i, j in zip(*np.nonzero((L[:-1, :] > 0) & (L[1:, :] > 0) & (L[:-1, :] != L[1:, :]))):
        ye = Y[i, j] - cell / 2
        key = tuple(sorted((int(L[i, j]), int(L[i + 1, j]))))
        pair_segs.setdefault(key, []).append(((X[i, j] - cell / 2, ye), (X[i, j] + cell / 2, ye)))

    ridge_parts, n_straight = [], 0
    for (la, lb), segs in sorted(pair_segs.items(), key=lambda kv: -len(kv[1])):
        raster_line = linemerge(MultiLineString(segs))
        straight = None
        try:
            straight = _straighten_pair(geoms, la, lb, fits, raster_line, segs, origin)
        except Exception:
            straight = None
        if straight is not None:
            ridge_parts.append(straight)
            n_straight += 1
        else:
            ridge_parts.append(raster_line.simplify(0.4))
    ridges = None
    if ridge_parts:
        ridges = unary_union(ridge_parts)
        if ridges.geom_type == "MultiLineString":
            ridges = linemerge(ridges)
    diag["ridges_straightened"] = f"{n_straight}/{len(pair_segs)}"

    planes = []
    for lid in lids:
        g = geoms[lid]
        if g.is_empty:
            continue
        st = stats[lid]
        a2 = float(g.area)
        planes.append({"area_2d": a2, "area_3d": a2 * st["factor"],
                       "slope_deg": st["slope_deg"], "aspect_deg": st["aspect_deg"],
                       "flat": st["flat"],
                       "geom": g.simplify(0.05, preserve_topology=True)})
    planes.sort(key=lambda p: -p["area_2d"])
    for i, p in enumerate(planes):
        p["id"] = i + 1

    # lappeet jotka ovat pääosin rakennuksen rajauksen ulkopuolella
    outside = [p["id"] for p in planes if p["geom"].area > 0 and
               p["geom"].intersection(building).area < 0.4 * p["geom"].area]
    if outside:
        diag["warning_outside"] = (
            "Lape " + ", ".join(map(str, outside)) + " on pääosin rajauksen ulkopuolella – "
            "onko se viereinen rakennelma (katos, terassi, puu)?")

    area_2d = sum(p["area_2d"] for p in planes)
    area_3d = sum(p["area_3d"] for p in planes)
    mean_slope = math.degrees(math.acos(min(1.0, area_2d / area_3d))) if area_3d > 0 else 0.0
    diag["planes"] = len(planes)
    diag["main_direction_deg"] = round(theta0 % 90, 1)
    return {"outline": outline, "planes": planes, "ridges": ridges,
            "area_2d": area_2d, "area_3d": area_3d, "mean_slope_deg": mean_slope,
            "building_area": building.area, "diagnostics": diag}


def aspect_to_compass(deg):
    if deg is None:
        return "–"
    return ["P", "KO", "I", "KA", "E", "LO", "L", "LU"][int((deg + 22.5) // 45) % 8]
