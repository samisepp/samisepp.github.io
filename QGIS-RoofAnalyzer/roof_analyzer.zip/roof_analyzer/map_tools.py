"""Karttatyökalut: rakennuksen valinta klikkaamalla ja polygonin piirto."""
from qgis.PyQt.QtCore import pyqtSignal
from qgis.PyQt.QtGui import QColor, QCursor
from qgis.gui import QgsMapTool, QgsRubberBand
from qgis.core import (QgsVectorLayer, QgsPointXY, QgsGeometry, QgsFeatureRequest,
                       QgsRectangle, QgsCoordinateTransform, QgsProject, QgsWkbTypes)

from . import compat

RESULT_LAYER_NAMES = ("Katon reuna", "Kattolappeet", "Harjat ja taitteet")


class BuildingPickTool(QgsMapTool):
    """Klikkaus valitsee rakennuksen mistä tahansa näkyvästä polygonitasosta.
    Aktiivinen taso tarkistetaan ensin, sitten muut ylhäältä alas."""

    picked = pyqtSignal(object, object, str)   # QgsGeometry, QgsCRS, tason nimi
    message = pyqtSignal(str)

    def __init__(self, canvas, iface):
        super().__init__(canvas)
        self.canvas = canvas
        self.iface = iface
        self.setCursor(QCursor(compat.PointingHandCursor))

    def _candidate_layers(self):
        layers = []
        active = self.iface.activeLayer()
        if isinstance(active, QgsVectorLayer):
            layers.append(active)
        for lyr in self.canvas.layers():
            if isinstance(lyr, QgsVectorLayer) and lyr not in layers:
                layers.append(lyr)
        return [l for l in layers
                if "Polygon" in QgsWkbTypes.displayString(l.wkbType())
                and l.name() not in RESULT_LAYER_NAMES]

    def canvasReleaseEvent(self, event):
        if event.button() != compat.LeftButton:
            return
        pt = event.mapPoint()
        canvas_crs = self.canvas.mapSettings().destinationCrs()
        tol = self.canvas.mapUnitsPerPixel() * 3
        layers = self._candidate_layers()
        if not layers:
            self.message.emit("Kartalla ei ole näkyvää polygonitasoa (esim. MTK:n rakennukset).")
            return
        for lyr in layers:
            tr = QgsCoordinateTransform(canvas_crs, lyr.crs(), QgsProject.instance())
            try:
                lp = tr.transform(pt)
                rect = tr.transformBoundingBox(QgsRectangle(pt.x() - tol, pt.y() - tol,
                                                            pt.x() + tol, pt.y() + tol))
            except Exception:
                continue
            pgeom = QgsGeometry.fromPointXY(QgsPointXY(lp))
            req = QgsFeatureRequest().setFilterRect(rect)
            best = None
            for f in lyr.getFeatures(req):
                g = f.geometry()
                if g and not g.isEmpty() and g.contains(pgeom):
                    if best is None or g.area() < best.area():   # sisäkkäisistä pienin
                        best = QgsGeometry(g)
            if best is not None:
                self.picked.emit(best, lyr.crs(), lyr.name())
                return
        self.message.emit("Klikkauskohdasta ei löytynyt rakennusta. Kokeile uudelleen tai piirrä rajaus.")


class PolygonDrawTool(QgsMapTool):
    """Polygonin piirto: vasen klikkaus lisää pisteen, oikea tai kaksoisklikkaus
    lopettaa, Backspace poistaa viimeisen pisteen, Esc peruu."""

    drawn = pyqtSignal(object, object)          # QgsGeometry, QgsCRS

    def __init__(self, canvas):
        super().__init__(canvas)
        self.canvas = canvas
        self.points = []
        self.band = QgsRubberBand(canvas, compat.polygon_geometry_type())
        self.band.setColor(QColor(255, 100, 0, 200))
        self.band.setFillColor(QColor(255, 100, 0, 40))
        self.band.setWidth(2)
        self.setCursor(QCursor(compat.CrossCursor))

    def _redraw(self, hover=None):
        pts = self.points + ([hover] if hover is not None else [])
        self.band.reset(compat.polygon_geometry_type())
        for i, p in enumerate(pts):
            self.band.addPoint(p, i == len(pts) - 1)

    def canvasMoveEvent(self, event):
        if self.points:
            self._redraw(QgsPointXY(event.mapPoint()))

    def canvasReleaseEvent(self, event):
        if event.button() == compat.LeftButton:
            self.points.append(QgsPointXY(event.mapPoint()))
            self._redraw()
        elif event.button() == compat.RightButton:
            self._finish()

    def canvasDoubleClickEvent(self, event):
        self._finish()

    def keyPressEvent(self, event):
        if event.key() == compat.Key_Escape:
            self.reset()
        elif event.key() == compat.Key_Backspace and self.points:
            self.points.pop()
            self._redraw()

    def _finish(self):
        pts = []
        for p in self.points:                     # poista peräkkäiset tuplapisteet
            if not pts or p.distance(pts[-1]) > 1e-6:
                pts.append(p)
        if len(pts) >= 3:
            geom = QgsGeometry.fromPolygonXY([pts])
            crs = self.canvas.mapSettings().destinationCrs()
            self.reset()
            self.drawn.emit(geom, crs)

    def reset(self):
        self.points = []
        self.band.reset(compat.polygon_geometry_type())

    def deactivate(self):
        self.reset()
        super().deactivate()
