def classFactory(iface):
    from .roof_analyzer_plugin import RoofAnalyzerPlugin
    return RoofAnalyzerPlugin(iface)
